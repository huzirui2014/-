# 胡子瑞的工具 - Android Linux超级终端

## 项目概述
这是一个功能完整的Android Linux超级终端模拟器应用。

## 功能特点

### 1. 完整Linux环境支持
- 兼容所有Android设备（Android 5.0+）
- 支持完整的Linux命令集
- 支持后台运行

### 2. 内置Linux命令库
- **adb命令**: 支持adb shell操作
- **input命令**: 支持input tap、input swipe、input text等
- **settings命令**: 完整的settings put/get/list/delete/reset支持
  - 一键开启开发者模式
  - 一键开启USB调试
  - 修改系统设置
- **系统命令**: ps, top, kill, chmod, chown等

### 3. Intent跳转支持
支持两种格式的Intent命令：
```
intent:#Intent;component=com.android.settings/.Settings$DevelopmentSettingsActivity;end
am start -a android.settings.APPLICATION_DEVELOPMENT_SETTINGS
am start -n com.android.settings/.Settings$DevelopmentSettingsActivity
```

### 4. Root超级权限
- 一键切换Root模式
- Root权限下执行命令无限制
- 自动检测Root可用性

### 5. 专业UI特性
- 黑色专业终端主题
- 语法高亮（命令、错误、成功状态）
- 命令历史记录（上下键导航）
- 快速设置按钮（开发者选项、USB调试等）
- 后台服务保持运行

## 快速命令示例

### 开启开发者选项
```
settings put global development_settings_enabled 1
```

### 开启USB调试
```
settings put global adb_enabled 1
setprop persist.sys.usb.config mtp,adb
```

### 显示触摸位置
```
settings put system show_touches 1
```

### 模拟点击
```
input tap 500 1000
```

### 模拟滑动
```
input swipe 500 1000 500 500
```

### 输入文字
```
input text "Hello World"
```

### 跳转到开发者设置
```
intent:#Intent;component=com.android.settings/.Settings$DevelopmentSettingsActivity;end
```

## 构建说明

### 环境要求
- Android Studio Arctic Fox (2020.3.1) 或更高版本
- JDK 11 或更高版本
- Android SDK 34
- Gradle 8.2+

### 构建步骤
1. 打开Android Studio
2. 选择 "Open an existing project"
3. 选择本目录
4. 等待Gradle同步完成
5. 点击 Build → Build Bundle(s) / APK(s) → Build APK(s)
6. APK将生成在 `app/build/outputs/apk/debug/app-debug.apk`

### 或者使用命令行构建
```bash
./gradlew assembleDebug
```

## 安装说明
1. 将APK传输到Android设备
2. 在设备上允许"未知来源"安装
3. 安装APK
4. 授予必要的权限（存储、Root等）

## 使用说明
1. 启动应用
2. 在输入框中输入命令
3. 点击RUN或按回车执行
4. 使用ROOT按钮切换超级权限
5. 使用DEV按钮快速访问开发者选项
6. 使用CLEAR按钮清屏

## 注意事项
- 部分命令需要Root权限
- 修改系统设置可能影响设备稳定性
- 请谨慎使用settings命令

## 文件结构
```
LinuxTerminalProject/
├── app/
│   ├── src/main/
│   │   ├── java/com/linuxterminal/
│   │   │   ├── MainActivity.java       # 主界面
│   │   │   └── TerminalService.java    # 后台服务
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── values/
│   │   │   └── drawable/
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
└── settings.gradle
```

## 许可证
MIT License
��─ drawable/
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
└── settings.gradle
```

## 许可证
MIT License
