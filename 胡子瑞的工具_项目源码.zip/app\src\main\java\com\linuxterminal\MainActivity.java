package com.linuxterminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView terminalOutput;
    private EditText commandInput;
    private ScrollView scrollView;
    private Button executeButton;
    private Button clearButton;
    private Button rootButton;
    private Button settingsButton;
    
    private List<String> commandHistory = new ArrayList<>();
    private int historyIndex = -1;
    private boolean isRootMode = false;
    private Process suProcess;
    private DataOutputStream suOutputStream;
    private BufferedReader suInputStream;
    private BufferedReader suErrorStream;
    
    // Command keywords for syntax highlighting
    private static final String[] COMMANDS = {
        "adb", "input", "settings", "am", "pm", "dumpsys", "logcat", "getprop", "setprop",
        "cd", "ls", "pwd", "cat", "echo", "mkdir", "rm", "cp", "mv", "chmod", "chown",
        "ps", "top", "kill", "su", "sh", "bash", "exit", "clear", "help"
    };
    
    private static final String[] SYSTEM_COMMANDS = {
        "settings", "put", "get", "list", "delete", "reset"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initializeViews();
        setupTerminal();
        checkPermissions();
        printWelcomeMessage();
        initializeRootShell();
    }
    
    private void initializeViews() {
        terminalOutput = findViewById(R.id.terminal_output);
        commandInput = findViewById(R.id.command_input);
        scrollView = findViewById(R.id.scroll_view);
        executeButton = findViewById(R.id.execute_button);
        clearButton = findViewById(R.id.clear_button);
        rootButton = findViewById(R.id.root_button);
        settingsButton = findViewById(R.id.settings_button);
        
        executeButton.setOnClickListener(v -> executeCommand());
        clearButton.setOnClickListener(v -> clearTerminal());
        rootButton.setOnClickListener(v -> toggleRootMode());
        settingsButton.setOnClickListener(v -> showSettingsMenu());
        
        commandInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE || 
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                executeCommand();
                return true;
            }
            return false;
        });
        
        commandInput.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                    navigateHistory(-1);
                    return true;
                } else if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    navigateHistory(1);
                    return true;
                }
            }
            return false;
        });
    }
    
    private void setupTerminal() {
        terminalOutput.setTextIsSelectable(true);
        terminalOutput.setHorizontallyScrolling(true);
    }
    
    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivity(intent);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, 
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE) 
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, 
                    new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }
        }
    }
    
    private void printWelcomeMessage() {
        appendOutput("========================================\n", 0xFF00FF00);
        appendOutput("  胡子瑞的工具 v1.0.0\n", 0xFF00FF00);
        appendOutput("========================================\n", 0xFF00FF00);
        appendOutput("Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n", 0xFF888888);
        appendOutput("Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n", 0xFF888888);
        appendOutput("Type 'help' for available commands\n\n", 0xFF888888);
    }
    
    private void initializeRootShell() {
        try {
            suProcess = Runtime.getRuntime().exec("su");
            suOutputStream = new DataOutputStream(suProcess.getOutputStream());
            suInputStream = new BufferedReader(new InputStreamReader(suProcess.getInputStream()));
            suErrorStream = new BufferedReader(new InputStreamReader(suProcess.getErrorStream()));
            isRootMode = true;
            updateRootButton();
        } catch (IOException e) {
            isRootMode = false;
            updateRootButton();
            appendOutput("Note: Root not available. Some commands may fail.\n", 0xFFFF8800);
        }
    }
    
    private void executeCommand() {
        String command = commandInput.getText().toString().trim();
        if (command.isEmpty()) return;
        
        commandHistory.add(command);
        historyIndex = commandHistory.size();
        
        appendOutput("$ " + command + "\n", 0xFF00AAFF);
        commandInput.setText("");
        
        if (command.equalsIgnoreCase("clear")) {
            clearTerminal();
            return;
        }
        
        if (command.equalsIgnoreCase("help")) {
            showHelp();
            return;
        }
        
        if (command.equalsIgnoreCase("exit")) {
            finish();
            return;
        }
        
        // Handle intent commands
        if (command.startsWith("intent:") || command.startsWith("am start")) {
            executeIntentCommand(command);
            return;
        }
        
        // Handle settings commands
        if (command.startsWith("settings ")) {
            executeSettingsCommand(command);
            return;
        }
        
        // Handle input commands
        if (command.startsWith("input ")) {
            executeInputCommand(command);
            return;
        }
        
        // Handle adb commands
        if (command.startsWith("adb ")) {
            executeAdbCommand(command);
            return;
        }
        
        // Execute shell command
        executeShellCommand(command);
    }
    
    private void executeShellCommand(String command) {
        new Thread(() -> {
            try {
                Process process;
                if (isRootMode && suProcess != null) {
                    suOutputStream.writeBytes(command + "\n");
                    suOutputStream.flush();
                    
                    // Read output with timeout
                    StringBuilder output = new StringBuilder();
                    StringBuilder error = new StringBuilder();
                    
                    Thread outputThread = new Thread(() -> {
                        try {
                            String line;
                            while ((line = suInputStream.readLine()) != null) {
                                output.append(line).append("\n");
                            }
                        } catch (IOException e) {
                            // Stream closed
                        }
                    });
                    
                    Thread errorThread = new Thread(() -> {
                        try {
                            String line;
                            while ((line = suErrorStream.readLine()) != null) {
                                error.append(line).append("\n");
                            }
                        } catch (IOException e) {
                            // Stream closed
                        }
                    });
                    
                    outputThread.start();
                    errorThread.start();
                    outputThread.join(5000);
                    errorThread.join(5000);
                    
                    final String result = output.toString();
                    final String err = error.toString();
                    
                    runOnUiThread(() -> {
                        if (!result.isEmpty()) {
                            appendOutput(result, 0xFFFFFFFF);
                        }
                        if (!err.isEmpty()) {
                            appendOutput(err, 0xFFFF0000);
                        }
                    });
                } else {
                    process = Runtime.getRuntime().exec(command);
                    
                    BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getInputStream()));
                    BufferedReader errorReader = new BufferedReader(
                        new InputStreamReader(process.getErrorStream()));
                    
                    StringBuilder output = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        output.append(line).append("\n");
                    }
                    
                    StringBuilder error = new StringBuilder();
                    while ((line = errorReader.readLine()) != null) {
                        error.append(line).append("\n");
                    }
                    
                    process.waitFor();
                    
                    final String result = output.toString();
                    final String err = error.toString();
                    
                    runOnUiThread(() -> {
                        if (!result.isEmpty()) {
                            appendOutput(result, 0xFFFFFFFF);
                        }
                        if (!err.isEmpty()) {
                            appendOutput(err, 0xFFFF0000);
                        }
                    });
                }
            } catch (Exception e) {
                final String error = "Error: " + e.getMessage() + "\n";
                runOnUiThread(() -> appendOutput(error, 0xFFFF0000));
            }
        }).start();
    }
    
    private void executeIntentCommand(String command) {
        new Thread(() -> {
            try {
                Intent intent;
                if (command.startsWith("intent:")) {
                    intent = Intent.parseUri(command, Intent.URI_INTENT_SCHEME);
                } else {
                    // Parse am start command
                    intent = parseAmStartCommand(command);
                }
                
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    runOnUiThread(() -> appendOutput("Intent executed successfully\n", 0xFF00FF00));
                }
            } catch (Exception e) {
                final String error = "Intent Error: " + e.getMessage() + "\n";
                runOnUiThread(() -> appendOutput(error, 0xFFFF0000));
            }
        }).start();
    }
    
    private Intent parseAmStartCommand(String command) {
        Intent intent = new Intent();
        String[] parts = command.split(" ");
        
        for (int i = 2; i < parts.length; i++) {
            if (parts[i].equals("-a") && i + 1 < parts.length) {
                intent.setAction(parts[i + 1]);
            } else if (parts[i].equals("-n") && i + 1 < parts.length) {
                String[] component = parts[i + 1].split("/");
                if (component.length == 2) {
                    intent.setClassName(component[0], component[0] + component[1]);
                }
            }
        }
        return intent;
    }
    
    private void executeSettingsCommand(String command) {
        new Thread(() -> {
            try {
                // Use settings binary
                Process process = Runtime.getRuntime().exec(command);
                process.waitFor();
                
                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));
                StringBuilder output = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
                
                final String result = output.toString();
                runOnUiThread(() -> {
                    if (result.isEmpty()) {
                        appendOutput("Settings command executed\n", 0xFF00FF00);
                    } else {
                        appendOutput(result, 0xFFFFFFFF);
                    }
                });
            } catch (Exception e) {
                final String error = "Settings Error: " + e.getMessage() + "\n";
                runOnUiThread(() -> appendOutput(error, 0xFFFF0000));
            }
        }).start();
    }
    
    private void executeInputCommand(String command) {
        new Thread(() -> {
            try {
                Process process = Runtime.getRuntime().exec(command);
                process.waitFor();
                runOnUiThread(() -> appendOutput("Input command executed\n", 0xFF00FF00));
            } catch (Exception e) {
                final String error = "Input Error: " + e.getMessage() + "\n";
                runOnUiThread(() -> appendOutput(error, 0xFFFF0000));
            }
        }).start();
    }
    
    private void executeAdbCommand(String command) {
        // ADB over network would require network debugging
        appendOutput("ADB commands: Use 'adb tcpip 5555' then connect via network\n", 0xFFFF8800);
        appendOutput("Or execute: adb shell <command>\n", 0xFFFF8800);
        
        // Try to execute the adb command locally
        executeShellCommand(command);
    }
    
    private void showHelp() {
        String help = "\n=== AVAILABLE COMMANDS ===\n\n" +
            "SHELL COMMANDS:\n" +
            "  ls, cd, pwd, cat, echo, mkdir, rm, cp, mv\n" +
            "  ps, top, kill, chmod, chown\n" +
            "  getprop, setprop, dumpsys, logcat\n\n" +
            "ANDROID COMMANDS:\n" +
            "  settings put <namespace> <key> <value>  - Modify system settings\n" +
            "  settings get <namespace> <key>          - Read system settings\n" +
            "  input tap <x> <y>                       - Simulate touch\n" +
            "  input swipe <x1> <y1> <x2> <y2>         - Simulate swipe\n" +
            "  input text <string>                     - Type text\n" +
            "  am start -n <package>/<activity>        - Start activity\n" +
            "  pm list packages                        - List installed apps\n" +
            "  pm install/uninstall <package>          - Install/uninstall apps\n\n" +
            "INTENT COMMANDS:\n" +
            "  intent:#Intent;component=com.android.settings/.Settings\$DevelopmentSettingsActivity;end\n" +
            "  am start -a android.settings.APPLICATION_DEVELOPMENT_SETTINGS\n\n" +
            "QUICK SETTINGS:\n" +
            "  Click 'DEV' button for quick developer options\n\n" +
            "OTHER:\n" +
            "  clear  - Clear terminal\n" +
            "  exit   - Close app\n\n";
        appendOutput(help, 0xFF888888);
    }
    
    private void showSettingsMenu() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quick Settings");
        
        String[] options = {
            "Developer Options",
            "USB Debugging (Toggle)",
            "OEM Unlocking",
            "Stay Awake",
            "Show Touches",
            "Pointer Location",
            "GPU Rendering",
            "Background Process Limit"
        };
        
        builder.setItems(options, (dialog, which) -> {
            switch (which) {
                case 0:
                    openDeveloperSettings();
                    break;
                case 1:
                    toggleUsbDebugging();
                    break;
                case 2:
                    executeCommandString("settings put global oem_unlock_allowed 1");
                    break;
                case 3:
                    executeCommandString("settings put global stay_on_while_plugged_in 3");
                    break;
                case 4:
                    executeCommandString("settings put system show_touches 1");
                    break;
                case 5:
                    executeCommandString("settings put system pointer_location 1");
                    break;
                case 6:
                    executeCommandString("settings put system debug.hwui.show_dirty_regions 1");
                    break;
                case 7:
                    executeCommandString("settings put global app_standby_enabled 0");
                    break;
            }
        });
        
        builder.show();
    }
    
    private void openDeveloperSettings() {
        try {
            Intent intent = new Intent();
            intent.setClassName("com.android.settings", 
                "com.android.settings.Settings$DevelopmentSettingsActivity");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            // Fallback
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
            startActivity(intent);
        }
    }
    
    private void toggleUsbDebugging() {
        executeCommandString("settings put global adb_enabled 1");
        executeCommandString("setprop persist.sys.usb.config mtp,adb");
        appendOutput("USB Debugging enabled\n", 0xFF00FF00);
    }
    
    private void executeCommandString(String command) {
        new Thread(() -> {
            try {
                if (isRootMode && suProcess != null) {
                    suOutputStream.writeBytes(command + "\n");
                    suOutputStream.flush();
                } else {
                    Runtime.getRuntime().exec(command);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void toggleRootMode() {
        if (isRootMode) {
            isRootMode = false;
            appendOutput("Root mode disabled\n", 0xFFFF8800);
        } else {
            try {
                suProcess = Runtime.getRuntime().exec("su");
                suOutputStream = new DataOutputStream(suProcess.getOutputStream());
                suInputStream = new BufferedReader(new InputStreamReader(suProcess.getInputStream()));
                isRootMode = true;
                appendOutput("Root mode enabled\n", 0xFF00FF00);
            } catch (IOException e) {
                appendOutput("Root not available on this device\n", 0xFFFF0000);
            }
        }
        updateRootButton();
    }
    
    private void updateRootButton() {
        runOnUiThread(() -> {
            if (isRootMode) {
                rootButton.setBackgroundColor(0xFF00AA00);
                rootButton.setText("ROOT: ON");
            } else {
                rootButton.setBackgroundColor(0xFFAA0000);
                rootButton.setText("ROOT: OFF");
            }
        });
    }
    
    private void clearTerminal() {
        terminalOutput.setText("");
        printWelcomeMessage();
    }
    
    private void navigateHistory(int direction) {
        if (commandHistory.isEmpty()) return;
        
        historyIndex += direction;
        if (historyIndex < 0) historyIndex = 0;
        if (historyIndex >= commandHistory.size()) {
            historyIndex = commandHistory.size();
            commandInput.setText("");
            return;
        }
        
        commandInput.setText(commandHistory.get(historyIndex));
        commandInput.setSelection(commandInput.getText().length());
    }
    
    private void appendOutput(String text, int color) {
        SpannableString spannable = new SpannableString(text);
        spannable.setSpan(new ForegroundColorSpan(color), 0, text.length(), 
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        terminalOutput.append(spannable);
        scrollToBottom();
    }
    
    private void scrollToBottom() {
        scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "Developer Options");
        menu.add(0, 2, 0, "Toggle Root");
        menu.add(0, 3, 0, "Clear History");
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                openDeveloperSettings();
                return true;
            case 2:
                toggleRootMode();
                return true;
            case 3:
                commandHistory.clear();
                historyIndex = -1;
                Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (suProcess != null) {
            try {
                suOutputStream.writeBytes("exit\n");
                suOutputStream.flush();
                suProcess.destroy();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
